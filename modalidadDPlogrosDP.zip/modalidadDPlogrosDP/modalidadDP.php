<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\modalidadMD;

class modalidadDP extends Controller
{
  public function index ()
  {
    return \App\modalidadMD::all();
  }
  public function show ($id)
  {
    return \App\modalidadMD::find($id);
  }
  public function store (Request $request)
  {
    //$objeto->campo=$
    return \App\modalidadMD::create($request->all());
  }
  public function update (Request $request, $id)
  {
    $registro=\App\modalidadMD::findOrFail($id);
    $registro->update($request->all());

    //return \App\clienteMD::update($request->all());

    return $registro;
  }
  public function destroy ($id)
  {
    $registro=\App\modalidadMD::findOrFail($id);
    $registro->delete();

    return 204;//indicaa el resultado cuando se toma una accion en internet en este caso 204 confirma que este programa proceso correctamente
  }
}
