<HTML>
<HEAD>
<TITLE>Calculadora</TITLE>
</HEAD>
<BODY>
  <h1>Resultados</H1>
  <p>
    holaaaaa
    <?php

        $num=2;
        return view('tips/$num');
    ?>
  </p>
</BODY>

</HTML>
