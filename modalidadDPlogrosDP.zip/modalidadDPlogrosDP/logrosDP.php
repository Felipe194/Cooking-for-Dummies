<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\logrosMD;

class logrosDP extends Controller
{
  public function index ()
  {
    return \App\logrosMD::all();
  }
  public function show ($id)
  {
    return \App\logrosMD::find($id);
  }
  public function store (Request $request)
  {
    //$objeto->campo=$
    return \App\logrosMD::create($request->all());
  }
  public function update (Request $request, $id)
  {
    $registro=\App\logrosMD::findOrFail($id);
    $registro->update($request->all());

    //return \App\clienteMD::update($request->all());

    return $registro;
  }
  public function destroy ($id)
  {
    $registro=\App\logrosMD::findOrFail($id);
    $registro->delete();

    return 204;//indicaa el resultado cuando se toma una accion en internet en este caso 204 confirma que este programa proceso correctamente
  }
}
